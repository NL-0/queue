<?php
     $conn =new mysqli('localhost', 'root', 'test' , 'blog_samples');
?>