<?php
	$servername = "localhost";
	$username = "user";
	$password = "pass";
	$dbname = "database";
	$tablename = "bookingcalendar";

	// translate these
	$months = array('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December');
	$headings = array('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday');
?>